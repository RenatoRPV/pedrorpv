package com.renato.renatoRPV.dominio;

public class Dev00PerfilBiologico {
    private String DNASeq;

    public String getDNASeq() {
        return DNASeq;
    }

    public void setDNASeq(String DNASeq) {
        this.DNASeq = DNASeq;
    }
}
